const LIST = [
    "kepek/kep1.jpg",
    "kepek/kep2.jpg",
    "kepek/kep3.jpg",
    "kepek/kep4.jpg",
    "kepek/kep5.jpg",
    "kepek/kep6.jpg",
    "kepek/kep7.jpg",
    "kepek/kep8.jpg",
    "kepek/kep1.jpg",
    "kepek/kep2.jpg",
    "kepek/kep3.jpg",
    "kepek/kep4.jpg",
    "kepek/kep5.jpg",
    "kepek/kep6.jpg",
    "kepek/kep7.jpg",
    "kepek/kep8.jpg",
    
  ];