const LIST = [
    "kepek/kep1.jpg",
    "kepek/kep2.jpg",
    "kepek/kep3.jpg",
    "kepek/kep4.jpg",
    "kepek/kep1.jpg",
    "kepek/kep2.jpg",
    "kepek/kep3.jpg",
    "kepek/kep4.jpg",
    
  ];
  let toggle = true
$(function(){
    const FELSOELEM = $("#felso");
    let tartalom = osszealit(LIST);
    FELSOELEM.append(tartalom);
    const KEPFELSO = $(".felsokep")
    KEPFELSO.on("click",csere)
    console.log(KEPFELSO)
    let CLICK = 0;
    let TALALAT = 0;
    KEPFELSO.on("click",osszehasonlit);
    
})
let txt = "";
function osszealit(LIST){
    
    for (let index = 0; index < LIST.length; index++){
        txt += `<div><img src="kepek/hatter.jpg" alt="" id="${index}" class="felsokep"></div>`;
        
      }
      console.log(txt);
    return txt;
    
}
function csere(event){
  toggle = !toggle
  if(toggle){
    $(event.target).attr("src", LIST[$(event.target).attr("id")]);
    CLICK++;
    
  }
  else{
    $(event.target).attr("src", "kepek/hatter.jpg");
  }
  
function osszehasonlit(event){
  if($(event.target).attr("src", LIST[$(event.target).attr("id")]) && CLICK === 1 && $(event.target).attr("src", LIST[$(event.target).attr("id")]) && CLICK === 2){
    TALALAT++;
    $(event.target).attr("src", "");
  }
  else{
    $(event.target).attr("src", "kepek/hatter.jpg"); 
  }
  CLICK = 0;
}

}
